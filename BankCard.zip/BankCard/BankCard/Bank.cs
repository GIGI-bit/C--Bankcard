﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankCard
{
    public class Bank
    {

        private List<Client>? _clients;
        
        public Bank(List<Client> clients)
        {
            this.Clients = clients;
        }

        public Bank()
        {

        }

        public List<Client> Clients
        {
            get { return _clients; }
            set { _clients = value; }
        }

        public void ShowCardBalance(Guid id)
        {
            Client client = null;

            foreach (var item in Clients)
            {
                if (item.Id == id) {
                    client = item;
                    break;
                }
            }

            if (client != null)
            {
                Console.WriteLine("Your Balance: "+client.BankAccount.Balance);
            }
            else
            {
                Console.WriteLine("Card not found in the bank.");
            }
        }
        public Client FindClientByPin(string userPin)
        {
            foreach (var client in Clients)
            {
                if (client.BankAccount != null && client.BankAccount.PIN == userPin)
                {
                    return client;
                }
            }

            return null; 
        }
    }
}
