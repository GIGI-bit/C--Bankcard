﻿using BankCard.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace BankCard.Logging
{
    public class History
    {
        private List<Node> _histories;
        public List<Node> Histories { get=>_histories; set=>_histories=value; }

        public History()
        {
            Histories = new List<Node>();
        }

        public History(List<Node> histories)
        {
            Histories = histories;
        }

        public void Show()
        {
            foreach (var history in Histories)
            {
                Console.WriteLine($"Process Time: {history.ProcessTime}, Process Name: {history.ProcessName}");
            }
        }
        public void UserLogIn(Guid id)=>
            this.Histories.Add(new Node(DateTime.Now, "User with Id No " + id.ToString() + " logged in."));
        public void DecreaseInBalance(Guid id, int moneyOut) =>
            this.Histories.Add(new Node(DateTime.Now, "User with Id No " + id.ToString() + " took out " + moneyOut.ToString() + " AZN from balance."));

        public void CardToCard(Guid id_1,Guid id_2,int money)=>
            this.Histories.Add(new Node(DateTime.Now, "User with Id No " + id_1.ToString() + " sent " + money.ToString() + " AZN to user with Id No "+id_2.ToString()));

        public void NotEnoughBalance(Guid id) =>
            this.Histories.Add(new Node(DateTime.Now, "User with Id No " + id.ToString() + " failed to take out money from balance."));
 
        public void ReviewHistory()
        {
            Console.Clear();
            DateTime currentDate=DateTime.Now;
            Console.WriteLine("Hansi muddetdeki kecmisi gormek isteyirsiniz?");
            Console.WriteLine("1. 1 gun evvel\n2. 5 gun evvel\n3. 10 gun evvel\n4. Hamisi");
            int input=int.Parse(Console.ReadLine());
            int daysAgo=0;
            if (input == 1) daysAgo = 1;
            else if (input == 2) daysAgo = 5;
            else if (input == 3) daysAgo = 10;
            else if(input == 4)
            {
                Show();
                Console.ReadKey();
                return;
            }
            var filteredHistories = Histories
            .Where(history => (currentDate - history.ProcessTime).Days <= daysAgo)
            .ToList();
        }
    
    }
}
