﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankCard.Logging
{
    public class Node
    {

        private DateTime processTime;
        private string processName;

        public DateTime ProcessTime
        {
            get { return processTime; }
            set { processTime = value; }
        }

        public string ProcessName
        {
            get { return processName; }
            set { processName = value; }
        }

        public Node()
        {
            processTime = DateTime.Now;
            processName = "Error 404";
        }

        public Node(DateTime time, string name)
        {
            processTime = time;
            processName = name;
        }
    }

}
