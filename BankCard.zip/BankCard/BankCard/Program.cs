﻿using BankCard;
using BankCard.Logging;

#region FakeDatas

var bankCards = new List<BankCard.BankCard>(5)
{
    new BankCard.BankCard("ABB","Pip Paule","3585414548790716","4116","273","09/27",2343.2432),
    new BankCard.BankCard("ABB", "Aura Blunsden", "201466893284836", "7796", "710", "01/27",72670.1576),
    new BankCard.BankCard("ABB", "Hally Dannell","3541060440700049","4257","688","08/29",181.8006),
    new BankCard.BankCard("ABB", "Constantine Sidwick","3556166300043875","5798","602","09/27",32951.422),
    new BankCard.BankCard("ABB","Vania Spini","3585414548790716","4116","273","09/27",2343.2432)
};

var users = new List<Client>(5) {
    new Client("Pip","Paule",21,2100,bankCards[0]),
    new Client("Aura","Blunsden",41,7000,bankCards[1]),
    new Client("Hally","Dannell",33,1200,bankCards[2]),
    new Client("Constantine","Sidwick",19,500,bankCards[3]),
    new Client("Vania","Spini",44,3200,bankCards[4]),
};

var bank = new Bank(users);
var history = new History();

#endregion

Console.Clear();
Console.WriteLine("Welcome to the Login Page!");
var newClient = GeneralFunctions.EnteringScreen(bank);
history.UserLogIn(newClient.Id);

while (true)
{
    Console.Clear();
    Console.WriteLine("Xos Gelmissiniz " + newClient.Name + " " + newClient.Surname + " zehmet olmasa asagidakilardan birini secerdiniz");
    Console.WriteLine("1. Balans\n2. Nagd pul\n3. Edilen emeliyyatlarin siyahisi\n4. Kartdan karta kocurme");
    int choice = int.Parse(Console.ReadLine());
    Console.Clear();

    if (choice == 1)
    {
        bank.ShowCardBalance(newClient.Id);
        Console.ReadKey();
    }
    else if (choice == 2)
    {
        Console.WriteLine(" 1. 10 AZN\n2. 20 AZN\n3. 50 AZN\n4. 100 AZN\n5. Diger (Istediyi meblegi ozu qeyd ede biler)");
        choice = int.Parse(Console.ReadLine());
        if (choice == 1 && newClient.BankAccount.Balance > 10)
        {
            newClient.BankAccount.Balance -= 10;
            history.DecreaseInBalance(newClient.Id, 10);
        }
        else if (choice == 2 && newClient.BankAccount.Balance > 20)
        {
            newClient.BankAccount.Balance -= 20;
            history.DecreaseInBalance(newClient.Id, 20);
        }
        else if (choice == 3 && newClient.BankAccount.Balance > 50)
        {
            newClient.BankAccount.Balance -= 50;
            history.DecreaseInBalance(newClient.Id, 50);
        }
        else if (choice == 4 && newClient.BankAccount.Balance > 100)
        {
            newClient.BankAccount.Balance -= 100;
            history.DecreaseInBalance(newClient.Id, 100);
        }
        else if (choice == 5)
        {
            int input = int.Parse(Console.ReadLine());
            if (newClient.BankAccount.Balance >= input) newClient.BankAccount.Balance -= input;
            else
            {
                Console.WriteLine("Your Balance IS NOT enough!");
                history.NotEnoughBalance(newClient.Id);
                Console.ReadKey();
                continue;
            }
            history.DecreaseInBalance(newClient.Id, input);
        }
        else if (choice > 5)
        {
            Console.WriteLine("This Choice DOES NOT exist!");
            Console.ReadKey();
            continue;
        }
        else
        {
            Console.WriteLine("Your Balance IS NOT enough!");
            history.NotEnoughBalance(newClient.Id);
            Console.ReadKey();
            continue;
        }
        Console.WriteLine("Sougunuz yerine yetirildi!");
        Console.ReadKey();
    }
    else if (choice == 3)
    {
        history.ReviewHistory();
        Console.ReadKey();
    }
    else if (choice == 4)
    {
        Console.WriteLine("Gondermek istediyiniz meblegi daxil edin: ");
        int money=int.Parse(Console.ReadLine());
        if (newClient.BankAccount.Balance < money)
        {
            Console.WriteLine("Your Balance IS NOT enough!");
            history.NotEnoughBalance(newClient.Id);
            Console.ReadKey();
            continue;
        }
        var toClient = GeneralFunctions.EnteringScreen(bank);

        if (toClient == null) 
        {
            Console.WriteLine("This user Not FOUND!");
            history.Histories.Add(new Node(DateTime.Now, "User with Id No " + newClient.Id.ToString() + " failed to sent money to another user."));
            Console.ReadKey();
            Console.Clear();
            Console.WriteLine("Welcome to the Login Page!");
            newClient = GeneralFunctions.EnteringScreen(bank);
            history.UserLogIn(newClient.Id);
        }
        else
        {
            newClient.BankAccount.Balance-=money;
            history.CardToCard(newClient.Id, toClient.Id, money);
            Console.ReadKey();
        }

    }






}

