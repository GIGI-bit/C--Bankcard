﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BankCard;

namespace BankCard
{
    using System;

    public class Client
    {
        private Guid _id;
        private string _name;
        private string _surname;
        private int _age;
        private double _salary;
        private BankCard _bankAccount;

        public Client()
        {
            _id = Guid.NewGuid();
        }

        public Client(string name, string surname, int age, double salary, BankCard bankCard)
        {
            _id = Guid.NewGuid();
            Name = name;
            Surname = surname;
            Age = age;
            Salary = salary;
            BankAccount = bankCard;
        }

        public Guid Id
        {
            get { return _id; }
        }

        public string Name
        {
            get { return _name; }
            set
            {
                if (value == null && value == "")
                {
                    throw new Exception("NULL or EMPTY values are NOT ACCEPTED!");
                }
                _name = value;
            }
        }

        public string Surname
        {
            get { return _surname; }
            set
            {
                if (value == null && value == "")
                {
                    throw new Exception("NULL or EMPTY values are NOT ACCEPTED!");
                }
                _surname = value;
            }
        }

        public int Age
        {
            get { return _age; }
            set
            {
                if (value < 0)
                {
                    throw new Exception("Age cannot be negative!");
                }
                _age = value;
            }
        }

        public double Salary
        {
            get { return _salary; }
            set
            {
                if (value <= 0)
                {
                    throw new Exception("Salary cannot be negative!");
                }
                _salary = value;
            }
        }

        public BankCard BankAccount
        {
            get { return _bankAccount; }
            set { _bankAccount = value; }
        }
    }

}
