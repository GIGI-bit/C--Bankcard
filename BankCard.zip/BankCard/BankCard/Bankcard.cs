﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankCard
{
    using System;

    public class BankCard
    {
        private string _bankName;
        private string _fullName;
        private string _pan;
        private string _pin;
        private string _cvc;
        private string _expDate;
        private double _balance;

        public BankCard() { }
        public BankCard(string bankName, string fullName, string pan, string pin, string cvc, string expDate, double balance)
        {
            BankName = bankName;
            FullName = fullName;
            _pan = pan;
            _pin = pin;
            _cvc = cvc;
            ExpDate = expDate;
            Balance = balance;
        }

        public string BankName
        {
            get => _bankName;
            set
            {
                if (value == null || value == "")
                    throw new Exception("NULL or EMPTY values are NOT ACCEPTED!");
                _bankName = value;
            }
        }

        public string FullName
        {
            get => _fullName;
            set
            {
                if (value == null || value == "")
                    throw new Exception("NULL or EMPTY values are NOT ACCEPTED!");
                _fullName = value;
            }
        }

        public string PAN
        {
            get => _pan;
            set
            {
                if (value == null || value == "")
                    throw new Exception("NULL or EMPTY values are NOT ACCEPTED!");
                _pan = value;
            }
        }

        public string PIN
        {
            get => _pin;
            set
            {
                if (value == null || value == "")
                    throw new Exception("NULL or EMPTY values are NOT ACCEPTED!");
                _pin = value;
            }
        }

        public string CVC
        {
            get => _cvc;
            set
            {
                if (value == null || value == "")
                    throw new Exception("NULL or EMPTY values are NOT ACCEPTED!");
                _cvc = value;
            }
        }

        public string ExpDate
        {
            get => _expDate;
            set
            {
                if (value == null || value == "") 
                    throw new Exception("NULL or EMPTY values are NOT ACCEPTED!");
                
                _expDate = value;
            }
        }

        public double Balance
        {
            get => _balance; 
            set 
            {
                if (value <0)
                    throw new Exception("NULL or EMPTY values are NOT ACCEPTED!");
                _balance = value; 
            
            }
        }
        
    }

}
