﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankCard;

public static class GeneralFunctions
{
    public static Client EnteringScreen(Bank bank)
    {

        while (true)
        {

            Console.Write("Enter PIN: ");
            string userPin = Console.ReadLine();
            var newClient = bank.FindClientByPin(userPin);

            if (newClient == null)
            {
                Console.WriteLine("PIN is incorrect!!!");
                Thread.Sleep(2000);
                continue;
            }
            else return newClient;
        }
    }




}
